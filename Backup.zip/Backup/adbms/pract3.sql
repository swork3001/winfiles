create table student(student_id serial primary key,name varchar(50),dept_id varchar(50));
create table employee(dept_id varchar(50), dept_name varchar(50));

---addtional step---
insert into student(name,dept_id) values('demo1',1),('demo2',3),('demo',2),('demo4',1),('demo5',3);
insert into employee(dept_id,dept_name) values(1,'IT'),(2,'ENG'),(3,'ART');

explain select * from employee where dept_name='IT';

create index idx_dept_name on employee(dept_name);
create index idx_stu_name on student(name);

explain select * from employee where dept_name='IT';

explain insert into student(name,dept_id) values('demo6',2);

explain delete from student where student_id=5;  ---safe delete using pk column

explain delete from student where dept_id='3';  ---dangerous delete if not used pk column

---testing----
select * from student;
select * from employee;