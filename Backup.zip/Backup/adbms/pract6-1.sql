---walog based recovery
show wal_level;

create table recovery_test(id int primary key, name varchar(50));

begin;
insert into recovery_test values(1,'demo1')
commit;

select * from recovery_test;

begin;
insert into recovery_test values(2,'demo2')

select * from recovery_test;