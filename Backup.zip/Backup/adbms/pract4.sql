create table student(student_id int primary key,name varchar(50));
create table marks(id int,marks int);

insert into student(student_id,name) values (1,'demo1'),(2,'demo2'),(3,'demo3'),(4,'demo4');
insert into marks(id,marks) values (1,80),(3,90),(5,85),(7,95);

select * from student s join marks m on s.student_id=m.id;

set enable_hashjoin=off;
set enable_mergejoin=off;
explain analyse select * from student s join marks m on s.student_id=m.id;

set enable_mergejoin=off;
set enable_nestloop=off;
explain analyse select * from student s join marks m on s.student_id=m.id;

set enable_nestloop=off;
set enable_mergejoin=off;
explain analyse select * from student s join marks m on s.student_id=m.id;



---reset after each explain analyse query
reset enable_nestloop;
reset enable_mergejoin;
reset enable_hashjoin;