create type adress_type as(city varchar(50), statee varchar(50));
create table person(person_id serial,name varchar(50),age int,address adress_type);
create table student(rollno int, course varchar(50))inherits (person);

insert into student(name,age,rollno,course)
values('demo1',21,101,'MCA');

insert into person(name,age,address)
values('demo2',23,row('kandivali','maharastra'));

update student set course='AI&ML' where rollno=101;

delete from student where rollno=101;

alter table student add primary key(person_id);

drop table student;
drop table person cascade;


---testing---
select * from person;
select * from student;
