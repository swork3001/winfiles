---shadow paging recovery
create table shadow_main(acc_no int primary key, name varchar(50), balance int);

insert into shadow_main values(101,'demo1',5000000);

create table shadow_copy as select * from shadow_main;

update shadow_copy set balance=balance-100000 where acc_no=101;

--if commited successfully
drop table shadow_main;
alter table shadow_copy rename to shadow_main;

--else if failure occured
drop table shadow_copy;


--testing
select * from shadow_main;
select * from shadow_copy;