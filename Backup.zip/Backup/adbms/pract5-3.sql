
---common
--step4
select * from pg_locks;