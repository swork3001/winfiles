---site2
--step2
create table department(dept_id int primary key,dept_name varchar(50),location varchar(50));
insert into department values(101,'IT','Mumbai'),(102,'HR','Pune');


---tesing
select * from department;