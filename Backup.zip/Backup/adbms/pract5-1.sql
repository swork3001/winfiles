---session1
--step1
create table accounts(id int primary key,name varchar(50),balance int);
insert into accounts(id,name,balance) values (1,'demo1',2000000),(2,'demo2',3000000);

select * from accounts;

begin;
update accounts set balance=balance-100000 where id=1; 

--step3
commit;

--step4
begin;
select * from accounts where id=2 for update;

--step6
commit;

--step7
begin;
update accounts set balance=balance-500 where id=1;

--step9
begin;
update accounts set balance=balance-100 where id=2;


