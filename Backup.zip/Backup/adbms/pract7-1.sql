---site1
--step1
create table employee(emo_id int primary key,emp_name varchar(50),dept_id int, salary int);
insert into employee values(1,'demo1',101,5000000),(2,'demo2',102,6000000),(3,'demo3',101,5500000);

--step3
create extension postgres_fdw;

--step4
create server site2_server 
foreign data wrapper postgres_fdw
options (host 'localhost', dbname 'pract7-site2', port '5432');

--step5
create user mapping for current_user
server site2_server
options (user 'postgres', password 'root');

--step6
create foreign table department_fdw(dept_id int,dept_name varchar(50), location varchar(50))
server site2_server
options (table_name 'department');

--extra cmd if you did typo error and want to redo in step6
DROP FOREIGN TABLE department_fdw;

--step7 main
select e.emp_name,e.salary,d.dept_name,d.location
from employee e
join department_fdw d
on e.dept_id=d.dept_id;

---tesing
select * from employee;