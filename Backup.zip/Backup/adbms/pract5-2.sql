---session2
--step2
begin;
update accounts set balance=balance+500 where id=1;

--step5
update accounts set balance=balance+100 where id=2;

--extra step6.5
commit;

--step8
begin;
update accounts set balance=balance-200 where id=2;

--step10
begin;
update accounts set balance=balance-100
