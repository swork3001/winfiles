--star schema demonstrated
--dimension tables
create table dim_customer(cust_id int primary key, cust_name varchar(50), city varchar(50));
create table dim_product(prod_id int primary key, prod_name varchar(50),category varchar(50));
create table dim_time(time_id int primary key, day int, month int, year int);

--fact table
create table fact_sales(sales_id serial primary key, 
cust_id int references dim_customer(cust_id),
prod_id int references dim_product(prod_id),
time_id int references dim_time(time_id),
amount decimal(10,2));

--inserting values in dimension tables
insert into dim_customer values (1,'demo1','mumbai'),(2,'demo2','pune');
insert into dim_product values (101,'laptop','electronis'),(102,'mobile','electronics');
insert into dim_time values(1001,1,4,2026),(1002,2,4,2026);

--innserting in fact table
insert into fact_sales (cust_id,prod_id,time_id,amount)
values (1,101,1001,50000),(2,102,1002,20000),(1,102,1002,15000);

--perfroming olap queries
--q1
select t.month,SUM(f.amount) as total_sales
from fact_sales f
join dim_time t on f.time_id=t.time_id
group by t.month;

--q2
select c.cust_name, SUM(f.amount)as total_sales
from fact_sales f
join dim_customer c on f.cust_id=c.cust_id
group by c.cust_name;

--q3
select p.category,SUM(f.amount) as total_sales
from fact_sales f
join dim_product p on f.prod_id=p.prod_id
group by p.category;



