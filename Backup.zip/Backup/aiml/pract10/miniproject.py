from sklearn.linear_model import LinearRegression
import pandas as pd

data={
    'Area':[100,1500,1800,2400],
    'Bedrooms':[2,3,3,4],
    'Bathrooms':[2,2,3,3],
    'Price':[3500000,5000000,6500000,9000000]
}

df=pd.DataFrame(data)

x=df[['Area','Bedrooms','Bathrooms']]
y=df[['Price']]

model=LinearRegression()
model.fit(x,y)

prediction=model.predict([[2000,3,2]])
print("Predicted Price:", prediction[0])