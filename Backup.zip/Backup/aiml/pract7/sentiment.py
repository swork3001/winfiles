from textblob import TextBlob

text="This product is very excellent and very easy to use."

analysis=TextBlob(text)

print("Sentiment Polarity:", analysis.sentiment.polarity)

if analysis.sentiment.polarity>0:
    print("Positive Sentiment")
elif analysis.sentiment.polarity<0:
    print("Negative Sentiment")
else:
    print("Neutral Sentiment")