print("-----Disease Diagnosis Expert System ----")

fever=input("Do you have fever? (yes/no):")
cough=input("Do you have cough? (yes/no):")
rash=input("Do you have rash? (yes/no):")
headache=input("Do you have headache (yes/no):")
vomiting=input("Do you have vomiting (yes/no):")

if fever=="yes" and cough=="yes":
    print("Diagnosis: you may have flu")
elif fever=="yes" and rash=="yes":
    print("Diagnosis: you may have measles")
elif headache=="yes" and vomiting=="yes":
    print("Diagnosis: you may have migraine")
else:
    print("Diagnosis: unable to detect disease, please consult a doctor")