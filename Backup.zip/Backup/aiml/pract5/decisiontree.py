from sklearn.tree import DecisionTreeClassifier

x=[[35,50000],[22,20000],[30,35000],[25,18000]]
y=['yes','no','yes','no']

model=DecisionTreeClassifier()
model.fit(x,y)

print(model.predict([[28,30000]]))