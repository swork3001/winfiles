from sklearn import svm

x=[[150,7],[170,8],[130,6],[140,6.5]]
y=['Apple','Apple','Orange','Orange']

model=svm.SVC(kernel='linear')
model.fit(x,y)

print(model.predict([[160,7]]))