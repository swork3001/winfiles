from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

X=[[45,50],[46,48],[85,90],[88,92],[25,30],[27,28]]

kmeans=KMeans(n_clusters=3)
kmeans.fit(X)

print(kmeans.labels_)

plt.scatter([x[0] for x in X],[x[1] for x in X],c=kmeans.labels_)
plt.show()