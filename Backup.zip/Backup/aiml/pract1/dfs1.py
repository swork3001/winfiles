def dfs(graph,start):
    visited=set()                #not needed

    if start not in visited:     #not needed
     print(start,end=" ")
     visited.add(start)          #not needed

     for neighbour in graph[start]:
             dfs(graph,neighbour)

graph={
    'A':['B','C'],
    'B':['D','E'],
    'C':['F'],
    'D':[],
    'E':[],
    'F':[]
}

dfs(graph,'A')
