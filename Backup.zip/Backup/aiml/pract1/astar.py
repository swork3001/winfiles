import heapq

def astar(graph,start,goal,heuristic):
    open_list=[]
    heapq.heappush(open_list,(0,start))

    g_cost={start:0}

    while open_list:
        current=heapq.heappop(open_list)[1]

        if current==goal:
            print("\nGoal Reached!")
            return

        for neighbour,cost in graph[current]:
            new_cost=g_cost[current]+cost

            if neighbour not in g_cost or new_cost<g_cost[neighbour]:
                g_cost[neighbour]=new_cost
                f_cost=new_cost+heuristic[neighbour]
                heapq.heappush(open_list,(f_cost,neighbour))

graph={
    'A':[('B',1),('C',3)],
    'B':[('D',1)],
    'C':[('D',1)],
    'D':[]
}

heuristic={
    'A':3,
    'B':1,
    'C':1,
    'D':1
}

astar(graph,'A','D',heuristic)