import numpy as np
from sklearn.linear_model import LogisticRegression

x=np.array([[1],[2],[3],[4],[5],[6]])
y=np.array([0,0,0,1,1,1])

model=LogisticRegression()
model.fit(x,y)

prediction=model.predict([[3.5]])
print("Prediction (0=Fail, 1=Pass):",prediction)