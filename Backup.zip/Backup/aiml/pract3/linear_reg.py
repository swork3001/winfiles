import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model  import LinearRegression

x=np.array([[1],[2],[3],[4],[5]])
y=np.array([200000,250000,300000,350000,400000])

model=LinearRegression()

model.fit(x,y)

predicted_salary=model.predict([[6]])

print('The salary after 6 years experience:',predicted_salary)

plt.scatter(x,y)
plt.plot(x,model.predict(x))
plt.xlabel("Experience")
plt.ylabel("salary")
plt.title("Linear regression")
plt.show()



