from xmlrpc.server import SimpleXMLRPCServer

server=SimpleXMLRPCServer(("localhost",8000))
print("RPC Sever is running on port 8000......")

def add(a,b):
    return a+b
def sub(a,b):
    return a-b
def mul(a,b):
    return a*b
def div(a,b):
    return a/b

server.register_function(add,"add")
server.register_function(sub,"sub")
server.register_function(mul,"mul")
server.register_function(div,"div")

server.serve_forever()