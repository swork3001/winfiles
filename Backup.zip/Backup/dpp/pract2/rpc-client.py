import xmlrpc.client

proxy=xmlrpc.client.ServerProxy("http://localhost:8000/")

print("Addition:", proxy.add(10,5))
print("Subtraction:", proxy.sub(10,5))
print("Multiplication:", proxy.mul(10,5))
print("Division:", proxy.div(10,5))