from multiprocessing import Process,Queue

def merge(left,right):
    result=[]
    i=j=0

    while i<len(left) and j<len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i+=1
        elif right[j]<left[i]:
            result.append(right[j])
            j+=1
        else:
            result.append(left[i])
            result.append(right[j])
            i+=1
            j+=1

    result.extend(left[i:])
    result.extend(right[j:])
    return result

def merge_sort(arr):
    if len(arr) <=1:
        return arr

    mid=len(arr)//2
    left=merge_sort(arr[:mid])
    right=merge_sort(arr[mid:])

    return merge(left,right)

def parallel_sort(arr,q):
    q.put(merge_sort(arr))

if __name__=="__main__":
    arr=[8,3,7,4,9,2,6,5]
    mid=len(arr)//2

    q1=Queue()
    q2=Queue()

    p1=Process(target=parallel_sort,args=(arr[:mid],q1))
    p2=Process(target=parallel_sort,args=(arr[mid:],q2))

    p1.start()
    p2.start()

    left=q1.get()
    right=q2.get()

    sorted_arr=merge(left,right)

    print("Original Array:", arr)
    print("Sorted Array:",sorted_arr)




