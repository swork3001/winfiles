import time
import random

class TimeServer:
    def get_time(self):
        return time.time()

class Client:
    def __init__(self,clock_offset):
        self.clock_offset=clock_offset

    def get_local_time(self):
        return time.time()+self.clock_offset

    def synchronize_clock(self,server):
        print("\n---Cristian's Algorithm---")

        T1=self.get_local_time()
        print("\nClient sends request at:",T1)

        delay=random.uniform(0.1,0.5)
        time.sleep(delay)

        server_time=server.get_time()

        time.sleep(delay)

        T2=self.get_local_time()
        print("\nClient receives response at:",T2)

        RTT=T2-T1
        print("Estimated RTT:", RTT)

        adjusted_time=server_time+(RTT/2)

        self.clock_offset=adjusted_time-time.time()

        print("\nNew client time:", self.get_local_time())

if __name__=="__main__":
    server=TimeServer()

    client=Client(clock_offset=-5)

    print("Initial Client Time:", client.get_local_time())
    print("Server Time:", server.get_time())

    client.synchronize_clock(server)
